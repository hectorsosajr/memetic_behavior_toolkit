﻿namespace MemeLibrary
{
    public class MemeManager
    {
        public void NotifyEnviromentEvent(MemeEvent memeEvent)
        {
        }
    }
}
