﻿namespace MemeLibrary
{
    public delegate void MemeEventHasFired(Meme meme, MemeEvent memeEvent);
}
