﻿namespace MemeController
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLog = new System.Windows.Forms.TextBox();
            this.pRoom1 = new System.Windows.Forms.Panel();
            this.pRoom2 = new System.Windows.Forms.Panel();
            this.pRoom3 = new System.Windows.Forms.Panel();
            this.pRoom4 = new System.Windows.Forms.Panel();
            this.pRoom5 = new System.Windows.Forms.Panel();
            this.btnLoad = new System.Windows.Forms.Button();
            this.pRoom6 = new System.Windows.Forms.Panel();
            this.pRoom7 = new System.Windows.Forms.Panel();
            this.pRoom8 = new System.Windows.Forms.Panel();
            this.pRoom9 = new System.Windows.Forms.Panel();
            this.pRoom10 = new System.Windows.Forms.Panel();
            this.btnStop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(13, 13);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(463, 168);
            this.txtLog.TabIndex = 0;
            // 
            // pRoom1
            // 
            this.pRoom1.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom1.Location = new System.Drawing.Point(13, 188);
            this.pRoom1.Name = "pRoom1";
            this.pRoom1.Size = new System.Drawing.Size(86, 49);
            this.pRoom1.TabIndex = 1;
            // 
            // pRoom2
            // 
            this.pRoom2.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom2.Location = new System.Drawing.Point(105, 188);
            this.pRoom2.Name = "pRoom2";
            this.pRoom2.Size = new System.Drawing.Size(86, 49);
            this.pRoom2.TabIndex = 2;
            // 
            // pRoom3
            // 
            this.pRoom3.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom3.Location = new System.Drawing.Point(197, 187);
            this.pRoom3.Name = "pRoom3";
            this.pRoom3.Size = new System.Drawing.Size(86, 49);
            this.pRoom3.TabIndex = 3;
            // 
            // pRoom4
            // 
            this.pRoom4.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom4.Location = new System.Drawing.Point(289, 187);
            this.pRoom4.Name = "pRoom4";
            this.pRoom4.Size = new System.Drawing.Size(86, 49);
            this.pRoom4.TabIndex = 4;
            // 
            // pRoom5
            // 
            this.pRoom5.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom5.Location = new System.Drawing.Point(381, 187);
            this.pRoom5.Name = "pRoom5";
            this.pRoom5.Size = new System.Drawing.Size(86, 49);
            this.pRoom5.TabIndex = 5;
            // 
            // btnLoad
            // 
            this.btnLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoad.Location = new System.Drawing.Point(105, 318);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(108, 48);
            this.btnLoad.TabIndex = 6;
            this.btnLoad.Text = "Start Memes";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // pRoom6
            // 
            this.pRoom6.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom6.Location = new System.Drawing.Point(13, 243);
            this.pRoom6.Name = "pRoom6";
            this.pRoom6.Size = new System.Drawing.Size(86, 49);
            this.pRoom6.TabIndex = 7;
            // 
            // pRoom7
            // 
            this.pRoom7.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom7.Location = new System.Drawing.Point(105, 243);
            this.pRoom7.Name = "pRoom7";
            this.pRoom7.Size = new System.Drawing.Size(86, 49);
            this.pRoom7.TabIndex = 8;
            // 
            // pRoom8
            // 
            this.pRoom8.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom8.Location = new System.Drawing.Point(197, 243);
            this.pRoom8.Name = "pRoom8";
            this.pRoom8.Size = new System.Drawing.Size(86, 49);
            this.pRoom8.TabIndex = 9;
            // 
            // pRoom9
            // 
            this.pRoom9.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom9.Location = new System.Drawing.Point(289, 242);
            this.pRoom9.Name = "pRoom9";
            this.pRoom9.Size = new System.Drawing.Size(86, 49);
            this.pRoom9.TabIndex = 10;
            // 
            // pRoom10
            // 
            this.pRoom10.BackColor = System.Drawing.Color.SkyBlue;
            this.pRoom10.Location = new System.Drawing.Point(381, 242);
            this.pRoom10.Name = "pRoom10";
            this.pRoom10.Size = new System.Drawing.Size(86, 49);
            this.pRoom10.TabIndex = 11;
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStop.Location = new System.Drawing.Point(232, 318);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(108, 48);
            this.btnStop.TabIndex = 12;
            this.btnStop.Text = "Stop Memes";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 378);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.pRoom10);
            this.Controls.Add(this.pRoom9);
            this.Controls.Add(this.pRoom8);
            this.Controls.Add(this.pRoom7);
            this.Controls.Add(this.pRoom6);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.pRoom5);
            this.Controls.Add(this.pRoom4);
            this.Controls.Add(this.pRoom3);
            this.Controls.Add(this.pRoom2);
            this.Controls.Add(this.pRoom1);
            this.Controls.Add(this.txtLog);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Meme Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Panel pRoom1;
        private System.Windows.Forms.Panel pRoom2;
        private System.Windows.Forms.Panel pRoom3;
        private System.Windows.Forms.Panel pRoom4;
        private System.Windows.Forms.Panel pRoom5;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Panel pRoom6;
        private System.Windows.Forms.Panel pRoom7;
        private System.Windows.Forms.Panel pRoom8;
        private System.Windows.Forms.Panel pRoom9;
        private System.Windows.Forms.Panel pRoom10;
        private System.Windows.Forms.Button btnStop;
    }
}

